package com.wangyin.ak47.core.stress;

public abstract class Collector<Q, R> {

}
