package com.wangyin.ak47.core.service;

import com.wangyin.ak47.core.Service;


public abstract class SimpleService<Q, R> implements Service<Q, R> {

}
