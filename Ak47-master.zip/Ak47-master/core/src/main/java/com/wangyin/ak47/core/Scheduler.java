package com.wangyin.ak47.core;

import java.util.concurrent.ScheduledExecutorService;


/**
 * 调度器
 * 
 * @author wyhanyu
 *
 */
public interface Scheduler extends ScheduledExecutorService {

}
